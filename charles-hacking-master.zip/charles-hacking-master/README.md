Hacking Charles Web Debugging Proxy

<http://www.gfzj.us/tech/2015/06/24/charles-hacking.html>